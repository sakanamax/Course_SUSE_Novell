#!/bin/bash
#sed is the command in objective 10

English="She sales seashells in the seashore, the seashells she sales in the seashore is not seashell I am sure."

echo "****** Before sed ******"
echo "$English"
echo -e "\033[32m"
echo "****** After sed without g ******"
echo "$English" | sed 's/sales/buy/'
echo -e "\033[34m"
echo "****** After sed with g    ******"
echo "$English" | sed 's/sales/buy/g'
echo -e "\033[0m"
