#! /bin/bash
# read is the command in objective 6
echo "****** Please Input your choice ******"
read CHOICE

echo ""
echo -e  "\033[31m"
echo "Your choice is $CHOICE"
