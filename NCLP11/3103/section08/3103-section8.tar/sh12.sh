#!/bin/bash
#while is the command in objective 4
while [ -n "$1" ]; do
    echo "\$1 is $1"
    echo "\$2 is $2"
    echo "Total arg is $#"
    echo "***************************************"
    shift
done
