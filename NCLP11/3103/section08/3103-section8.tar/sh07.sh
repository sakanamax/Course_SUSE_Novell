#! /bin/bash
# -n --> nonzero
echo "****** Check \$USER ******"
echo "Your \$USER is $USER"
echo "**************************"

[ -n $USER -a "$USER" = "root" ] && echo "You are login with root, Be careful!!"
[ -n $USER -a "$USER" = "root" ] || echo "You are login with normal user, do your daily work!!"

