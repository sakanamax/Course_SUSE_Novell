#! /bin/bash
# argcount() is function, in objective 9
echo $0
echo $1
echo $2
echo $3
echo $4
echo $5
echo $@
echo $*
argcount() {
   echo "Number of arguments: $#"
   echo '$1:' "$1"
}
echo 'argcount "$@"'
argcount "$@"
echo 'argcount "$*"'
argcount "$*"
echo OVER
echo "Total argu is $#"
