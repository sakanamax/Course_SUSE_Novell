#!/bin/bash
# until is the command in objective 4

secret=''
until [ "$secret" = "linux" ]; do
    echo "Enter your favorite OS name"
    read secret
done
echo "I love linux"
