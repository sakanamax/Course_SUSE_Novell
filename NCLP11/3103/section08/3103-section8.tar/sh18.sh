#!/bin/bash
# cut is the command in objective 10
echo "****** Check \$yourip  ******"
echo "Yourip is $yourip"
echo ""
echo "****** Let's get your ip ******"
yourip=`ifconfig | grep Bcast | cut -d : -f 2 | cut -d ' ' -f 1 `
echo "Your IP is $yourip"
