#! /bin/bash
echo "****** Check /home ******"
ls --color=tty /home
echo "*************************"


for (( i=100 ; i < 120 ; i=i+1 ));
   do
     echo "Add user x$i"
     useradd -m x$i
     echo 1234 | passwd --stdin x$i
     echo "done"
   done

echo "****** After script check /home ******"
ls --color=tty /home
echo "**************************************"
