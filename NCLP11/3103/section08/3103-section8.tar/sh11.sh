#! /bin/bash
#let, $(( )), is the command in objective 5
a=100
b=200

c=$a+$b
echo "\$c is $c"
echo ""

d=$(( $a+$b ))
echo "\$d is $d"
echo ""

let e=$a+$c
echo "\$e is $e"
