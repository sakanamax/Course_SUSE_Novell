#! /bin/bash
# -e --> exist
echo "****** Check /home/joe/dir/******"
ls --color=tty /home/joe/dir
echo ""
echo "****** Check /home/joe     ******"
ls --color=tty /home/joe
echo ""

if [ -e /home/joe/dir/file1 ]; then
   rm -rf /home/joe/dir/file1
   echo "file1 exist--> deleted"
 elif [ -d /home/joe/dir ]; then
      echo "The /home/joe/dir exist, We will create file1"
      touch /home/joe/dir/file1
 else
      echo "the dir non-exist, We will create one!!"
      mkdir /home/joe/dir
fi

echo "****** After Script Check /home/joe/dir/******"
ls --color=tty /home/joe/dir
echo ""
echo "****** After Script Check /home/joe     ******"
ls --color=tty /home/joe
echo ""
