#!/bin/bash
#tr is the command in objective 10

English="She sales seashells in the seashore, the seashells she sales in the seashore is not seashell I am sure."
echo -e "\033[32m"
echo "****** Before tr ******"
echo "$English"
echo ""
echo -e "\033[0m"
echo "****** After tr  ******"
result=`echo "$English" | tr 'a-z' 'A-Z' `
echo "$result"
