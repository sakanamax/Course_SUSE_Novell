#!/bin/bash
# array in objective 7

#set value to array
sample[0]="zero"
sample[1]="one"
sample[2]="three"

#show value
for i in 0 1 2; do
echo "sample[$i]=${sample[$i]}"
done
