#! /bin/bash
ls  --color=tty /home/joe
echo ""
[ -f /home/joe/dir1 ] && echo  "******/home/joe/dir1 exist!! Nothing to Do!!******"
[ -f /home/joe/dir1 ] || echo  "******/home/joe/dir1 is not exist, We will create one******"
[ -f /home/joe/dir1 ] || touch /home/joe/dir1
echo ""
ls  --color=tty /home/joe

