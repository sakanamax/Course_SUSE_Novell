1.Please add a user joe in your system
#useradd -m joe

2.Download the 3103section8.tar to your /root/Desktop

3.exact it in joe's home directory
#cd /home/joe
#tar xvf /root/Desktop/3103section3.tar
#ls

4.Start exercise
