#! /bin/bash
# for is the command in objective 4
echo "****** Check /home ******"
ls --color=tty /home
echo ""
echo "****** We will create user account in /home/joe/userlist ******"
echo "****** There are users list ******"
cat /home/joe/userlist
echo "**********************************"

for i in $( cat /home/joe/userlist )
   do
      echo "Add user $i  "
      useradd -m $i
      echo 1234 | passwd --stdin $i
      echo "done"
   done

echo "****** After script check /home ******"
ls --color=tty /home
echo "**************************************"
