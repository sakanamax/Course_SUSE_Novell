#!/bin/bash
#case is the command in objective 4

echo "****** Please enter Yes or No ******"
echo ""
read yesno

case "$yesno" in
     y*|Y*)
     echo "Your answer is YES"
     ;;
     [nN]*)
     echo "Your answer is NO"
     ;;
         *)
     echo "You type wrong word"
esac
