#! /bin/bash
# if is in objective 4,
# -d --> directory
echo "****** Check /home/joe ******"
ls --color=tty /home/joe
echo ""

if [ -d /home/joe/dir ]; then
   echo "the Dir /home/joe/dir exist, Nothing to do"
else
   echo "the Dir non-exist, We will create one!!"
   mkdir /home/joe/dir
fi

echo ""
echo "****** Check /home/joe ******"
ls --color=tty /home/joe
