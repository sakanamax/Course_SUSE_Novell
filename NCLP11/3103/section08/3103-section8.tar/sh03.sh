#! /bin/bash
# [] is the test command in objective 4, -f --> file
ls --color=tty /home/joe

[ -f /home/joe/dir1 ] || echo "******/home/joe/dir1 is not exist******"
[ -f /home/joe/dir1 ] && echo "******/home/joe/dir1 is exist******"


