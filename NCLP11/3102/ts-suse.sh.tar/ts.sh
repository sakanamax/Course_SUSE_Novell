#!/bin/bash
rcnetwork stop > /dev/null 2>&1 
rm -rf /etc/sysconfig/network/ifcfg-eth*
echo " you can start trouble shooting"

