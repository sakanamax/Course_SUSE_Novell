#!/bin/bash
route del default gw `route -n | grep UG | cut -d' ' -f 10`
echo " you can start trouble shooting"
