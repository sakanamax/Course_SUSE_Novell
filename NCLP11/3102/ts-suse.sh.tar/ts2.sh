#!/bin/bash
echo "1234" > /etc/resolv.conf
echo "you can start trouble shooting"
